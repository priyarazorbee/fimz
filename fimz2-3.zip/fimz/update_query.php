<?php
	require_once 'conn.php';
	
	if(ISSET($_POST['update'])){
		$id = $_POST['id'];
		$status = $_POST['status'];
		
		mysqli_query($conn, "UPDATE `contact` SET `status` = '$status' WHERE `id` = '$id'") or die(mysqli_error());

		header("location: indexs.php");
	}
?>