<?php
	$conn = mysqli_connect("localhost", "fimz", "fimz123#", "fimz");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>