<?php
if(isset($_POST['submit_pass']) && $_POST['pass'])
{
 $pass=$_POST['pass'];
 if($pass=="123")
 {
  $_SESSION['password']=$pass;
     header("location: index.php");
 }
 else
 {
  $error="Incorrect Pssword";
 }
}
?>