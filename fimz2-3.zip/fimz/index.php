<!doctype html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <title>FIMZ Group</title>
      <meta name="viewport" content="width=575" />
      <meta name="robots" content="nofollow">
      <meta content="fimz,fimz group,personal loan agents in bangalore,home loan,personal loan,loan guidance in bangalore,Mentor for loans,loan calculator" name="keywords">
      <meta content="Fimz help customers choose the best & most-suited financial products and constructions. Since 2017, we have earned the trust and goodwill of over 1 million consumers. We continue to work hard to help you make the best financial decisions and provide the best experience on our platform." name="description">
      <!-- Google Fonts -->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

      <!-- Bootstrap CSS File -->
      <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
       <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
       <link href="css/style.css" rel="stylesheet">
       <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="css/form.css" >
        <!--<script src="form.js"></script>-->
   
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<meta name="google-site-verification" content="MOXBVOSv4SF0qLkB6_MwKMHVxcHPN1cXLAjyMqs2kik" />
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-2QFF90D30R"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-2QFF90D30R');
</script>  
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WQSQ22P');</script>
<!-- End Google Tag Manager -->
</head>
   
<script>
    $(document).ready(function(){
  $('.customer-logos').slick({
    slidesToShow: 6,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1000,
    arrows: false,
    dots: false,
    pauseOnHover: false,
    responsive: [{
      breakpoint: 768,
      settings: {
        slidesToShow: 4
      }
    }, {
      breakpoint: 520,
      settings: {
        slidesToShow: 3
      }
    }]
  });
});
    </script>
    
    

    

<body data-spy="scroll" data-target="#navbar-example">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WQSQ22P"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <header>
    
        <div id="sticker" class="header-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12 col-sm-12">

                <!-- Navigation -->
                <nav class="navbar navbar-default">
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
                                            <span class="sr-only">Toggle navigation</span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>
                    
                    <a class="navbar-brand page-scroll sticky-logo" href="index.php">


                      <img class="logoimg" src="img/logo.png" alt="The loan " title="FIMZGroup_logo" style="">
                                    </a>
                                    <!--<img class="logoimg" src="img/fimzgroup.jpeg" alt="The loan " title="FIMZGroup_logo" style="">-->
                                   
                  </div>
 <h5 class="header">Financial Investment Management Zone</h5>
                </nav>
               
              </div>
            </div>
          </div>
        </div>

      
      <img src="img/money-home-coin-investment.jpg" alt="loan calculator" style="width:100%;height:100%;">
    
  </header>
    
    <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>About FIMZ Group</h2>
          </div>
        </div>
      </div>
      <div class="row">
        
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
     <img class="aboutimg" src="img/why-choose-us.png" alt="Personal Loan , home loan arrangement with planning and materials" style="height:280px;width:550px;">
								</a>
            </div>
          </div>
        </div>
       
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <h4 class="sec-head">Why  Choose Us?</h4>
              </a>
              <p style="text-align:justify;">Using data and technology innovations, we help customers choose the best & most-suited financial products and constructions. Since 2017, we have earned the trust and goodwill of over 1 million consumers. We continue to work hard to help you make the best financial decisions and provide the best experience on our platform.
                </p>
                
              <ul>
                <li>
                    <i class="fa fa-check"></i> <strong >With Us Personal Loans:</strong> A personal loan is a type of unsecured loan and helps to meet one’s current financial needs.
                </li>
                <li>
                    <i class="fa fa-check"></i><strong>With Us FIMZ HOMEY:</strong> Construction materials: your dream home/commercial building/ offices can mean excitement, happiness, contentment and a lot more. But with great happiness and achievement also comes with planning and research so does your budged aside for your construction project
                </li>
                </ul>
            </div>
          </div>
        </div>
       
      </div>
    </div>
  </div>  
    

    <div id="about" class="area-padding1">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Our Services</h2>
          </div>
        </div>
      </div>
<div class="row1">
  <div class="column12">
    <div class="card">
      <img class="aboutimg" src="img/personal_loan.png" alt="Personal loan arrangements with Punctual process" style="height:280px;width:550px;">
      <div class="container12">
        <h2 style="text-align:center;">Personal Loan</h2>
        
        <p style="padding-left:15px;text-align:justify;">A personal loan is a type of unsecured loan and helps to meet one’s current financial needs. One usually doesn’t need to pledge any security or collateral while availing of a personal loan and the lender provides the flexibility to use the funds as per one’s need. It can serve as a solution for funding holidays and wedding expenses, as well as medical emergencies, home renovation, debt consolidation and others. </p>
        <ul>
                <li>
                    <i class="fa fa-check"></i> Tie Up with Leading Banks and NBFCs.
                </li>
                <li>
                    <i class="fa fa-check"></i>Personal Loans / Business Loans .
                </li>
            <li>
                    <i class="fa fa-check"></i>Doorstep Service and A Dedicated Sales Manager.
                </li>
            <li>
                    <i class="fa fa-check"></i>Selected most fundable start-ups in India since 2017.
                </li>
            <li>
                    <p style="margin-bottom:17px;"> <i class="fa fa-check"></i>Leadership team comprises of Senior Ex Bankers.</p>
            </li>
          </ul>
      </div>
    </div>
  </div>

  <div class="column12">
    <div class="card">
      <img class="aboutimg" src="img/Homey.png" alt="Home loan with Planning and purchase of construction materials" style="height:280px;width:550px;">
      <div class="container12">
        <h2 style="text-align:center;margin-bottom:17px;">Homey Construction Materials</h2>
        
        
          
          <ul>
                <li>
                    <i class="fa fa-check"></i> <strong>Convenience:</strong>  100% Responsibility from Plan Approval to Handover.
                </li>
                <li>
                    <i class="fa fa-check"></i><strong>Transparency:</strong> Transparent at every level (progress, payment, material purchase).
                </li>
                <li>
                    <i class="fa fa-check"></i><strong>Cost:</strong> Fixed pre-agreed project cost with standardized packages.
                </li>
                <li>
                    <i class="fa fa-check"></i> <strong>On-Time:</strong> Set project schedule tracked & managed, with penalty for delay.
                </li>
                <li>
                    <i class="fa fa-check"></i> <strong>Quality of finish:</strong> Strong team of contractors, in-house team of architects, engineers, project managers. Only branded materials used.
                </li>
                  <li>
                     <p style="margin-bottom:35px;"> <i class="fa fa-check line123"></i> <strong>Technology:</strong>Powered by technology - starting from vendor on-boarding to automated progress report and payment flow.</p>
                </li>
                  
              </ul>
          
      </div>
    </div>
  </div>
    
  
    

  </div>
  </div>
  </div>
      <!-- direction 1 -->
    
   <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Our Personal Loan Partners</h2>
          </div>
        </div>
      </div> 
   <div class="container">
  <section class="customer-logos slider">
    <div class="slide"><img alt="Hdfc Bank" src="img/client_logo/Hdfc-Logo-PNG.png"></div>
    <div class="slide"><img alt="Aditya-birla" src="img/client_logo/Aditya-birla_logo.jpg"></div>
    <div class="slide"><img alt="HDB" src="img/client_logo/HDB_logo.png"></div>
    <div class="slide"><img alt="Axis Bank" src="img/client_logo/Axis_logo.png"></div>
    <div class="slide"><img alt="IndusInd-Bank" src="img/client_logo/IndusInd-Bank-logo.jpg"></div>
    <div class="slide"><img alt="ICICI Bank" src="img/client_logo/icici_bank_logo.png"></div>
    <div class="slide"><img alt="IDFC_First_Bank" src="img/client_logo/IDFC_First_Bank_logo.jpg"></div>
    
  </section>
</div>
</div>
</div>
    
    
    <div id="about" class=" area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Careers</h2>
          </div>
        </div>
      </div> 
        <div class="container">
            <!-- Form Started -->
            <div class="container form-top">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
                        <div class="panel panel-danger">
                            <div class="panel-body">
 
    
              <form action=''  role="form" id="reused_form" enctype="multipart/form-data">
            <div id='responsed'></div>
                                    <div class="form-group">
                                        <label><i class="fa fa-user" aria-hidden="true"></i> Name</label>
                                        <input type="text" id="name" name="name" class="form-control" placeholder="Enter Name" required>
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fa fa-envelope" aria-hidden="true"></i> Email</label>
                                        <input type="email" id="email" name="email" class="form-control" placeholder="Enter Email" required>
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fa fa-comment" aria-hidden="true"></i> Message</label>
                                        <textarea rows="3" id="message" name="message" class="form-control" placeholder="Type Your Message" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fa fa-upload" aria-hidden="true" ></i>Upload Resume</label>
                                        <input type="file" name="file" class="form-control" required accept="application/pdf,application/msword,
  application/vnd.openxmlformats-officedocument.wordprocessingml.document"/>
                                    </div>
                                   <!--<div class="g-recaptcha" data-sitekey="6LfP_0QaAAAAAL15j20lqtbKAjfnHEYRKUfKnJ5c"></div>-->
                                    <div class="form-group">
                                        <input type="submit" name="sends" class="btn btn-raised  btn-danger btn_size">
                                    </div>
                  </form>

     </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Form Ended -->
        </div>	</div> 
				</div>		
  		
    
    
  <div id="contact" class="contact-area">
    <div class="contact-inner about-area  area-padding">
      <div class="contact-overly"></div>
      <div class="container ">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>Contact us</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-mobile"></i>
                <p>
                  Call: +91-9343778866<br>
                  <span>Monday-Saturday </span>
                </p>
              </div>
            </div>
          </div>
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-envelope-o"></i>
                <p>
                  Email:fairoz.ahmed@fimzgroup.com <br>
                  <span>www.fimzgroup.com</span>
                </p>
              </div>
            </div>
          </div>
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-map-marker"></i>
                <p>
                    #9 3rd F Main Nagamma Layout Kavalbysandra<br> 
                    R T Nagar Bangalore 560032

                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">

          <!-- Start Google Map -->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <!-- Start Map -->
            <div class="mapouter"><div class="gmap_canvas"><iframe class="gmap_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=570&amp;height=380&amp;hl=en&amp;q= Nagamma Layout Kavalbysandra R T Nagar Bangalore 560032&amp;t=k&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://piratebayproxy.net/">pirate bay proxy</a></div><style>.mapouter{position:relative;text-align:right;width:570px;height:380px;}.gmap_canvas {overflow:hidden;background:none!important;width:570px;height:380px;}.gmap_iframe {width:570px!important;height:380px!important;}</style></div>
            <!-- End Map -->
              
          </div>
          <!-- End Google Map -->

          <!-- Start  contact -->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="form contact-form">
 
          <form action="" method="post" role="form" class="contactForm" id="my_form_id">
              <div id='response'></div>
              
                <div class="form-group">
                  <input type="text" name="names" class="form-control" id="names" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <input type="email" class="form-control" name="emails" id="emails" placeholder="Your Email" data-rule="email" required />
                  <div class="validation"></div>
                </div>
                 <div class="form-group">
                  <select required="required" name="loan" class="form-control" id="loan">
                     <option disabled value="" selected hidden>Choose a Product</option>
                     <option value="Homey">Homey </option>
                     <option value="Personal loan">Personal loan</option>
                  </select>
                
               </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone Number" required />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <textarea class="form-control" name="messages" id="messages" rows="5" required placeholder="Message"></textarea>
                  <div class="validation"></div>
                </div>
                <!--<div class="g-recaptcha" data-sitekey="6LfP_0QaAAAAAL15j20lqtbKAjfnHEYRKUfKnJ5c"></div>-->
                <div class="text-center"><input name="send" type="submit"></div>
              </form>
             </div>
          </div>
          <!-- End Left contact -->
          
        </div>
        </div>
        </div>
         <div class="chat-whatsapp">
			<a target="_blank" href="https://api.whatsapp.com/send?phone=+919343778866&text=hello" data-original-title="whatsapp" rel="tooltip" data-placement="right" data-action="share/whatsapp/share"><img src="img/whatsappchat.png" alt="" title="Whatsapp Chat"></a>&nbsp;&nbsp;<a  target="_blank" href="https://www.facebook.com/implbm/?ref=page_internal"><img src="img/fb.png" alt="" title="Whatsapp Chat"></a>&nbsp;&nbsp;<a  target="_blank" href=""><img src="img/linkedin.png" alt="" title="Whatsapp Chat"></a>
		</div>
      
    
   
  </div>
  <!-- End Contact Area -->


  
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>


        <script>
            $(document).ready(function(){
                $('#reused_form').on('submit', function(e){
                   var formData = new FormData($(this)[0]);
                 event.preventDefault();
                    // var email = $('#email').val();
                    // var name=$('#name').val();
                    //   var message=$('#message').val();
                    //  var file=$('input[type=file]').val().replace(/.*(\/|\\)/, '');
                    $.ajax({
                        type: "POST",
                       url:"files.php",
                     
                        dataType: "json",
                        // data: {"email": email,'name':name,"file":file,"message":message},
                        data:formData,
                          success: function(data) {
                 $("#responsed").html(data.message);
                  $("#responsed").css("color", "green");
                     $('#reused_form').trigger('reset');
                } ,
            error: function() {
                    $("#responsed").html(data.message);
                    $("#responsed").css("color", "red");
                     $('#reused_form').trigger('reset');
                } ,
                 cache: false,
    contentType: false,
    processData: false
                    });
                    return false;
                });
                $('#my_form_id').on('submit', function(e){
                    //Stop the form from submitting itself to the server.
                    e.preventDefault();
                    var emails = $('#emails').val();
                    var names=$('#names').val();
                      var phone=$('#phone').val();
                      var messages=$('#messages').val();
                     var loan=$("#loan option:selected").text();
                    $.ajax({
                        type: "POST",
                        url: 'test.php',
                        dataType: "json",
                        data: {"emails": emails,'names':names,"loan":loan,"phone":phone,"messages":messages},
                    success: function(data) {
                    $("#response").html(data.message);
                  $("#response").css("color", "green");
                     $('#my_form_id').trigger('reset');
                } ,
            error: function() {
                    $("#response").html(data.message);
                    $("#response").css("color", "red");
                     $('#my_form_id').trigger('reset');
                } , 
                    });
                });
            });
        </script>
</body>

</html>