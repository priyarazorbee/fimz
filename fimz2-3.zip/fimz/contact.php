<?php
header('Cache-Control: no cache'); //no cache
session_cache_limiter('private_no_expire'); // works
//session_cache_limiter('public'); // works too
session_start();

if(isset($_POST['submit_pass']) && $_POST['pass'])
{
 $pass=$_POST['pass'];
 if($pass=="123")
 {
  $_SESSION['password']=$pass;
 }
 else
 {
  $error="Incorrect Pssword";
 }
}

if(isset($_POST['page_logout']))
{
 unset($_SESSION['password']);
}
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:white;
}
#wrapper p
{
 font-size:16px;
}
#logout_form input[type="submit"]
{
 width:250px;
 margin-top:10px;
 margin-left:70%;
 height:40px;
 font-size:16px;
 background-color:#dddddd;
 border:2px solid #dddddd;
 color:black;
}
#login_form
{
 margin-top:200px;
 background-color:white;
 width:350px;
 margin-left:310px;
 padding:20px;
 box-sizing:border-box;
 box-shadow:0px 0px 10px 0px #3B240B;
}
#login_form h1
{
 margin:0px;
 font-size:25px;
 color:#8A4B08;
}
#login_form input[type="password"]
{
 width:250px;
 margin-top:10px;
 height:40px;
 padding-left:10px;
 font-size:16px;
}
#login_form input[type="submit"]
{
 width:250px;
 margin-top:10px;
 height:40px;
 font-size:16px;
 background-color:#8A4B08;
 border:none;
 box-shadow:0px 4px 0px 0px #61380B;
 color:white;
 border-radius:3px;
}
#login_form p
{
 margin:0px;
 margin-top:15px;
 color:#8A4B08;
 font-size:17px;
 font-weight:bold;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;

}

table tr::before {

  padding-right: 0.3em;
  padding-top: 0.8em;
  text-align: right;
  border: 1px solid #dddddd;
}
tbody{
    counter-reset: rowNumber;
}
tbody tr::before {
  display: table-cell;
  counter-increment: rowNumber;
  content: counter(rowNumber) ".";

}
thead tr::before {
  display: none!important;
  
}
td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
    <div id="wrapper">

<?php
if($_SESSION['password']=="123")
{
 ?>

 <form method="post" action="" id="logout_form">
  <input type="submit" name="page_logout" value="LOGOUT">
 </form>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "fimz", "fimz123#", "fimz");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM contact";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<h2 style='margin: 0 auto;text-align: center;'>View Contact</h2>";
        echo "<table style='margin: 0 auto;'>";
        echo "<thead>";
            echo "<tr style='text-align: left;border-bottom: 1px solid #ddd;'>";
             echo "<th>id</th>";
                echo "<th  style='text-align: left;border-bottom: 1px solid #ddd;'>Name</th>";
                echo "<th  style='text-align: left;border-bottom: 1px solid #ddd;'>Email</th>";
                echo "<th  style='text-align: left;border-bottom: 1px solid #ddd;'>Loan</th>";
                echo "<th  style='text-align: left;border-bottom: 1px solid #ddd;'>Phone</th>";
                echo "<th  style='text-align: left;border-bottom: 1px solid #ddd;'>Messge</th>";
                echo "<th  style='text-align: left;border-bottom: 1px solid #ddd;'>Status</th>";
                echo "<th  style='text-align: left;border-bottom: 1px solid #ddd;'>Date Received</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";
        while($row = mysqli_fetch_array($result)){
            
            echo "<tr>";
                // echo "<td>" . $row['id'] . "</td>";
                echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" .  $row['names'] . "</td>";
                echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['emails'] . "</td>";
                echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['loan'] . "</td>";
                echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['phone'] . "</td>";
                echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['messages'] . "</td>";
                 echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['status'] . "<button type=button class=btn btn-info btn-lg data-toggle=modal data-target=#myModal" . $row['id'] . "><img src=img/edit.png></button></td><div class=modal fade id=myModal" . $row['id'] . " role=dialog>
    <div class=modal-dialog>
    
      <!-- Modal content-->
      <div class=modal-content>
        <div class=modal-header>
          <button type=button class=close data-dismiss=modal></button>
          <h4 class=modal-title>Change Status</h4>
        </div>
        <div class=modal-body>
        <form method=post class=form-horizontal id=updateForm>
         <input type=hidden id=" . $row['id'] . " name=id value=" . $row['id'] . " />	
        <div class=form-group>
                  <label for=status>Status</label> <br/>
                  <select name=status id=action>
                     <option>Choose a value</option>
                     <option value=active>Active</option>
                     <option value=progress>Progress</option>
                     <option value=close>close</option>
                  </select>
                  
               </div>
               <button name=update class=btn btn-warning><span class=glyphicon glyphicon-edit></span> Update</button>
               <button type=button class=btn btn-default data-dismiss=modal>Close</button>
               </form>
        </div>
        
      </div>
      
    </div>
  </div>";
                 echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . date('Y-m-d', strtotime($row['time'])). "</td>";
            echo "</tr>";
            
        }
        echo "</tbody>";
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
<?php
	$link = mysqli_connect("localhost", "fimz", "fimz123#", "fimz");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	
	if(ISSET($_POST['update'])){
		$id = $_POST['id'];
		$status = $_POST['status'];
	$sql="UPDATE `contact` SET `status` = '$status' WHERE `id` = '$id'";

	if(	mysqli_query($link, $sql)){
	echo "db updated successfully";
		header("Location : http://project.razorbee.com/fimz/contact.php");
	}
else { echo "db update failed";}
	}
?>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "fimz", "fimz123#", "fimz");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM career";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<h2 style='margin: 0 auto;text-align: center;margin-top:30px;'>View Career</h2>";
       echo "<table style='margin: 0 auto;'>";
            echo "<thead>";
            echo "<tr style='text-align: left;border-bottom: 1px solid #ddd;'>";
             echo "<th>id</th>";
                echo "<th style='text-align: left;border-bottom: 1px solid #ddd;'>Name</th>";
                echo "<th style='text-align: left;border-bottom: 1px solid #ddd;'>Email</th>";
                echo "<th style='text-align: left;border-bottom: 1px solid #ddd;'>Messge</th>";
                echo "<th style='text-align: left;border-bottom: 1px solid #ddd;'>File</th>";
                 echo "<th style='text-align: left;border-bottom: 1px solid #ddd;'>Status</th>";
                  echo "<th style='text-align: left;border-bottom: 1px solid #ddd;'>Date Received</th>";
            echo "</tr>";
             echo "</thead>";
            echo "<tbody>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                // echo "<td>" . $row['id'] . "</td>";
                echo "<td style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['name'] . "</td>";
                echo "<td style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['email'] . "</td>";
                echo "<td style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['message'] . "</td>";
                 
 echo "<td style='text-align: left;border-bottom: 1px solid #ddd;'>
<a class=word href=//docs.google.com/gview?url=http://project.razorbee.com/fimz/data/" . $row['file'] . "&embedded=true>";
      echo $row['file'];
 echo "</a></td>"; 
echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . $row['status'] . "<button type=button class=btn btn-info btn-lg data-toggle=modal data-target=#myModal" . $row['id'] . "><img src=img/edit.png></button></td><div class=modal fade id=myModal" . $row['id'] . " role=dialog>
    <div class=modal-dialog>
    
      <!-- Modal content-->
      <div class=modal-content>
        <div class=modal-header>
          <button type=button class=close data-dismiss=modal></button>
          <h4 class=modal-title>Change Status</h4>
        </div>
        <div class=modal-body>
        <form method=post class=form-horizontal id=updateForm>
         <input type=hidden id=" . $row['id'] . " name=id value=" . $row['id'] . " />	
        <div class=form-group>
                  <label for=status>Status</label> <br/>
                  <select name=status id=action>
                     <option>Choose a value</option>
                     <option value=active>Active</option>
                     <option value=progress>Progress</option>
                     <option value=close>close</option>
                  </select>
                  
               </div>
               <button name=updates class=btn btn-warning><span class=glyphicon glyphicon-edit></span> Update</button>
               <button type=button class=btn btn-default data-dismiss=modal>Close</button>
               </form>
        </div>
        
      </div>
      
    </div>
  </div>";
  echo "<td  style='text-align: left;border-bottom: 1px solid #ddd;'>" . date('Y-m-d', strtotime($row['date'])). "</td>";
               
            echo "</tr>";
        }
         echo "</tbody>";
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "Updated Successfully";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
<?php
	$link = mysqli_connect("localhost", "fimz", "fimz123#", "fimz");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	
	if(ISSET($_POST['updates'])){
		$id = $_POST['id'];
		$status = $_POST['status'];
	$sql="UPDATE `career` SET `status` = '$status' WHERE `id` = '$id'";

	if(	mysqli_query($link, $sql)){
	echo " db updated successfully";
	header("Location : http://project.razorbee.com/fimz/contact.php");
	}
else { echo "db update failed";}
	}

}
else
{
 ?>
 <form method="post" action="" id="login_form">
  <h1>LOGIN TO PROCEED</h1>
  <input type="password" name="pass" placeholder="*******">
  <input type="submit" name="submit_pass" value="DO SUBMIT">
 
  <p><font style="color:red;"><?php echo $error;?></font></p>
 </form>
 <?php	
}
?>
<script>
    $(document).ready(function() {
 $(".word").fancybox({
  'width': 600, // or whatever
  'height': 320,
  'type': 'iframe'
 });
}); 
</script>
</body>
</html>