              <?php 
              error_reporting(E_ALL);
ini_set('display_errors', 1);
$link = mysqli_connect("localhost", "fimz", "fimz123#", "fimz");
   $loan=$_POST['loan'];
   $names=$_POST['names'];
   $emails=$_POST["emails"];
   $phone=$_POST["phone"];
   $messages=$_POST["messages"];
   $status="active";
  $EmailSubject = $loan. 'form submitted'; 
  $from_email='noreply@fimzgroup.com';
   $email_message = $loan.' Request Submitted
                    Name: '.$names.'
                    Email: '.$emails.'
                    Phone:'.$phone.'
                    Message:'.$messages.'';
    $mailheader = "From: ".$emails."\r\n"; 
    $mailheader .= "Reply-To: ".$emails."\r\n"; 
    
    
    // $secretKey="6LfP_0QaAAAAACltihU37CeCSNBsSsyl8fkdPD78";
    // $responseKey=$_POST['g-recaptcha-response'];
    // $UserIP=$_SERVER['REMOTE_ADDR'];
    // $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$responseKey&remoteip=$UserIP";

    // $data=file_get_contents($url);
    // $data=json_decode($data);
  $ToEmail="priya@razorbee.com";	  
    
         

$sql = "INSERT INTO contact (names, emails,phone,messages,loan,status,time) VALUES ('$names', '$emails','$phone','$messages','$loan','$status',now())";
$data= mysqli_query($link, $sql);
    if($data){
     
     mail($ToEmail, $EmailSubject, $email_message, $mailheader);
     echo json_encode(array('status' => 'success','message'=> 'Thanks for your response we will get back to you!!.'));

    
}
else{
    echo json_encode(array('status' => 'failure','message'=> 'something went wrong try again later!!.'));


}



?>