<?php
	require_once 'conn.php';
	
	if(ISSET($_POST['delete'])){
		$id = $_POST['id'];
		
		echo $id;
		
 $sql = "DELETE FROM contact WHERE id='$id'";
if(mysqli_query($conn, $sql)){
    header("location: indexs.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
	}
?>