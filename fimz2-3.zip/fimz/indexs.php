<?php
header('Cache-Control: no cache'); //no cache
session_cache_limiter('private_no_expire'); // works
//session_cache_limiter('public'); // works too
session_start();

if(isset($_POST['submit_pass']) && $_POST['pass'])
{
 $pass=$_POST['pass'];
 if($pass=="123")
 {
  $_SESSION['password']=$pass;
 }
 else
 {
  $error="Incorrect Pssword";
 }
}

if(isset($_POST['page_logout']))
{
 unset($_SESSION['password']);
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
	</head>
    <style>
    tbody{
    counter-reset: rowNumber;
}
tbody tr::before {
  display: table-cell;
  counter-increment: rowNumber;
  content: counter(rowNumber) ".";
    border: 1px solid #dddddd;

}
thead tr::before {
  display: none!important;
  
}
    #wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:white;
}
#wrapper p
{
 font-size:16px;
}
#logout_form input[type="submit"]
{

 color:black;
}
#login_form
{
 margin-top:200px;
 background-color:white;
 width:350px;
 margin-left:310px;
 padding:20px;
 box-sizing:border-box;
 box-shadow:0px 0px 10px 0px #3B240B;
}
#login_form h1
{
 margin:0px;
 font-size:25px;
 color:#8A4B08;
}
#login_form input[type="password"]
{
 width:250px;
 margin-top:10px;
 height:40px;
 padding-left:10px;
 font-size:16px;
}
#login_form input[type="submit"]
{
 width:250px;
 margin-top:10px;
 height:40px;
 font-size:16px;
 background-color:#8A4B08;
 border:none;
 box-shadow:0px 4px 0px 0px #61380B;
 color:white;
 border-radius:3px;
}
#login_form p
{
 margin:0px;
 margin-top:15px;
 color:#8A4B08;
 font-size:17px;
 font-weight:bold;
}
    </style>
<body>
    
    <div id="wrapper">

<?php
if($_SESSION['password']=="123")
{
 ?>

        
        <div class="col-md-12">
        <nav class="navbar navbar-light bg-dark">
  <a class="navbar-brand" href="#">
    <img class="logoimg" src="img/logo.png" alt="The loan " title="FIMZGroup_logo" style=" width:16%; height:53px;" alt="">
  </a>
    <form method="post" action="" id="logout_form">
  <input type="submit" name="page_logout" value="LOGOUT" style="margin-left:65%;margin-top:-3%;">
 </form>
</nav> 
            </div>
 <h1></h1>
<!--
 <form method="post" action="" id="logout_form">
  <input type="submit" name="page_logout" value="LOGOUT" style="margin-left: 65%;">
 </form>
-->
	
	
	<div class="col-md-12">
		<h3 class="text-primary">View Contact</h3>
<!--		<hr style="border-top:1px dotted #ccc;"/>-->
<!--		<button type="button" class="btn btn-success" data-toggle="modal" data-target="#form_modal"><span class="glyphicon glyphicon-plus"></span> Add user</button>-->
		<br /><br />
		<table class="table table-bordered">
			<thead class="alert-success">
				<tr>
                    <th>id</th>
					<th>Name</th>
					<th>Email</th>
					<th>Loan</th>
                <th>Phone</th>
                <th>Message</th>
                <th>Status</th>
                <th>Date Received</th>
					<th>Action</th>
                    
				</tr>
			</thead>
			<tbody style="background-color:#fff;">
				<?php
					require 'conn.php';
					$query = mysqli_query($conn, "SELECT * FROM `contact`") or die(mysqli_error());
					while($fetch = mysqli_fetch_array($query)){
				?>
				<tr>
					
					<td><?php echo $fetch['names']?></td>
                    <td><?php echo $fetch['emails']?></td>
					<td><?php echo $fetch['loan']?></td>
                    <td><?php echo $fetch['phone']?></td>
                    <td><?php echo $fetch['messages']?></td>
                    <td><?php echo $fetch['status']?></td>
                    <td><?php echo date('Y-m-d', strtotime($fetch['time']))?></td>
					<td><button class="btn btn-warning" data-toggle="modal" type="button" data-target="#update_modal<?php echo $fetch['id']?>"><span class="glyphicon glyphicon-edit"></span> Edit</button><br/><br/><button class="btn btn-danger" data-toggle="modal" type="button" data-target="#delete_modal<?php echo $fetch['id']?>"><span class="glyphicon glyphicon-edit"></span> Delete</button></td>
				</tr>
				<?php
					
					include 'update_user.php';
                        include 'delete_contact.php';
					
					}
				?>
			</tbody>
		</table>
	</div>

	
	<div class="col-md-12">
		<h3 class="text-primary">View Career</h3>
<!--		<hr style="border-top:1px dotted #ccc;"/>-->
<!--		<button type="button" class="btn btn-success" data-toggle="modal" data-target="#form_modal"><span class="glyphicon glyphicon-plus"></span> Add user</button>-->
		<br /><br />
		<table class="table table-bordered">
			<thead class="alert-success">
				<tr>
                    <th>id</th>
					<th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>File</th>
                 <th>Status</th>
                  <th>Date Received</th>
                    <th>Action</th>
				</tr>
			</thead>
			<tbody style="background-color:#fff;">
				<?php
					require 'conn.php';
					$query = mysqli_query($conn, "SELECT * FROM `career`") or die(mysqli_error());
					while($fetchs = mysqli_fetch_array($query)){
				?>
				<tr>
					
					<td><?php echo $fetchs['name']?></td>
                <td><?php echo $fetchs['email'] ?></td>
                <td><?php echo $fetchs['message'] ?></td>
                <td>
<a class="word" href="//docs.google.com/gview?url=http://project.razorbee.com/fimz/data/<?php echo  $fetchs['file'] ?>&embedded=true">
     <?php echo $fetchs['file']?></a></td> 
                    <td><?php echo $fetchs['status']?></td>
                    <td><?php echo date('Y-m-d', strtotime($fetchs['date']))?></td>
					<td><button class="btn btn-warning" data-toggle="modal" type="button" data-target="#update_modals<?php echo $fetchs['id']?>"><span class="glyphicon glyphicon-edit"></span> Edit</button><br/><br/><button class="btn btn-danger" data-toggle="modal" type="button" data-target="#delete_modals<?php echo $fetchs['id']?>"><span class="glyphicon glyphicon-edit"></span> Delete</button></td>
				</tr>
				<?php
										include 'update_career.php';
                        include 'delete_career.php';
					
					
					}
				?>
			</tbody>
		</table>
	</div>
	<?php
}
else
{
 ?>
 <form method="post" action="" id="login_form">
  <h1>LOGIN TO PROCEED</h1>
  <input type="password" name="pass" placeholder="*******">
  <input type="submit" name="submit_pass" value="DO SUBMIT">
  <p>"Password : 123"</p>
<!--  <p><font style="color:red;"><?php echo $error;?></font></p>-->
 </form>
 <?php	
}
?>

</div>
<script src="js/jquery-3.2.1.min.js"></script>	
<script src="js/bootstrap.js"></script>	
    <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
</body>	
</html>