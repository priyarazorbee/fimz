<?php
$link = mysqli_connect("localhost", "fimz", "fimz123#", "fimz");
$email = $_POST['email'];
    $name = $_POST['name'];
    $message = $_POST['message'];
$fromemail =  $email;
$status="active";
$subject="Uploaded file attachment";
$email_message = '<h2>Resume from online</h2>
                    <p><b>Name:</b> '.$name.'</p>
                    <p><b>Email:</b> '.$email.'</p>
                    <p><b>Message:</b><br/>'.$message.'</p>';
                    
$email_message.="Please find the attachment";
$semi_rand = md5(uniqid(time()));
$headers = "From: ".$fromemail;
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";

    $headers .= "\nMIME-Version: 1.0\n" .
    "Content-Type: multipart/mixed;\n" .
    " boundary=\"{$mime_boundary}\"";

	$strFilesName = $_FILES["file"]["name"];  
	$strFiles = $e_type = str_replace(' ', '_', $strFilesName);
	
	$strContent = chunk_split(base64_encode(file_get_contents($_FILES["file"]["tmp_name"])));  
	
	
    $email_message .= "This is a multi-part message in MIME format.\n\n" .
    "--{$mime_boundary}\n" .
    "Content-Type:text/html; charset=\"iso-8859-1\"\n" .
    "Content-Transfer-Encoding: 7bit\n\n" .
    $email_message .= "\n\n";


    $email_message .= "--{$mime_boundary}\n" .
    "Content-Type: application/octet-stream;\n" .
    " name=\"{$strFilesName}\"\n" .
    //"Content-Disposition: attachment;\n" .
    //" filename=\"{$fileatt_name}\"\n" .
    "Content-Transfer-Encoding: base64\n\n" .
    $strContent  .= "\n\n" .
    "--{$mime_boundary}--\n";

    // $secretKey="6LfP_0QaAAAAACltihU37CeCSNBsSsyl8fkdPD78";
    // $responseKey=$_POST['g-recaptcha-response'];
    // $UserIP=$_SERVER['REMOTE_ADDR'];
    // $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$responseKey&remoteip=$UserIP";
    
    // $response=file_get_contents($url);
    // $response=json_decode($response);
    move_uploaded_file($_FILES['file']['tmp_name'],"data/".$strFiles);
$sql = "INSERT INTO career (name, email,message,file,status,date)VALUES ('$name', '$email','$message','$strFiles','$status',now())";

    $ToEmail="priya@razorbee.com";	
   $data= mysqli_query($link, $sql);
    if($data){
     mail($ToEmail,$subject, $email_message, $headers);
     echo json_encode(array('status' => 'success','message'=> 'Updated Successfully.'));

    
}
else{
    echo json_encode(array('status' => 'failure','message'=> 'something went wrong try again later!!.'));


}
?>